# Mission Template

Use this structure when briefing an execution agent.

## Mission
State the product or release objective in one sentence.

## Current reality
State what is already true so the agent does not re-explore solved setup.

## Constraints
List non-negotiables:
- architecture
- secrets
- release style
- preview-first requirement

## Required outcomes
List visible outcomes, not abstract goals.

## Validation
Define what must be true for the round to count as successful.
