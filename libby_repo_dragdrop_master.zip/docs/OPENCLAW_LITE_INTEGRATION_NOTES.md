# OpenClaw Lite Integration Notes

## Recovered intent
OpenClaw is not a random add-on. Recovered doctrine treats it as the intended automation / heartbeat layer.

## What OpenClaw should be in phase 1
- internal automation layer
- dispatcher
- bounded task runner
- reminder and state-check process
- workflow accelerator for known-safe internal tasks

## What OpenClaw should not be in phase 1
- uncontrolled autonomous operator
- public-facing professional authority
- direct legal / medical / financial decision maker
- broad client-facing automation without approval boundaries

## Recovered governance requirements
Before serious automation goes live, the following should exist in usable form:
- role definition
- host model
- credentials and access boundaries
- allowed vs prohibited actions
- human approval matrix
- prompt-injection handling / security posture
- phase-1 automation backlog
- workspace prompt files such as `AGENTS.md`, `SOUL.md`, and `TOOLS.md`

## Best immediate use
Once canonical docs exist, OpenClaw Lite can:
- refresh evidence index files
- run bounded prompt packets
- check stale tasks
- prepare summaries
- assist with controlled file workflows
- act as a dispatcher between Gmail / Drive / repo work
