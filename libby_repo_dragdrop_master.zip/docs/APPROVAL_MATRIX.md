# Approval Matrix

## No approval needed
- internal docs updates
- changelog updates
- non-secret repo structure docs
- preview-only UI adjustments
- bounded wording / copy improvements

## Approval required
- production merge
- architecture shift
- auth behavior changes with user-facing risk
- external integrations beyond the current stack
- anything that changes canonical Patient Zero meaning substantially
- anything that changes legal / medical framing in public-facing outputs

## Never do automatically
- expose secrets
- rotate secrets
- send external filings or legal/medical submissions
- destructive deletes
- credential sharing
