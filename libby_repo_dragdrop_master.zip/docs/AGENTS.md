# Agents

## Core execution model
- Claude = implementation and integration
- ChatGPT = operating logic and synthesis
- Gemini = retrieval and inventory
- OpenClaw Lite = bounded dispatch later

## Canon rule
No single chat session is the canon.
Repo files are the canon.
