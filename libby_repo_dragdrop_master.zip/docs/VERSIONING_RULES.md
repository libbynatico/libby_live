# Versioning Rules

## Rule 1
Every meaningful release round must visibly bump versioning.

## Rule 2
A version bump is not complete unless it appears in:
- document title
- visible version indicator in the UI
- internal version constant
- settings / status surface if present
- `CHANGELOG.md`

## Rule 3
A preview that does not look visibly different within 10 seconds of opening it should not be considered a successful release pass.

## Rule 4
Version format guidance
- live / merged release: `vX.Y.Z-label`
- preview / agent release: `vX.Y.Z-agent-previewN`

## Current target
- next target preview: `v2.01.0-claude-preview1`
