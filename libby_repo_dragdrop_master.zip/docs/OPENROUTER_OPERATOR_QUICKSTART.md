# OpenRouter Operator Quickstart

## For the founder
You do not need to learn OpenRouter deeply to keep Libby working.

### What matters
- create or copy an API key in OpenRouter
- store it in Netlify as `OPENROUTER_API_KEY`
- never paste it into GitHub
- let the Netlify function use it

### If chat stops working
Check in this order:
1. Netlify env var still exists
2. function deploy still exists
3. browser is calling `/.netlify/functions/chat`
4. function returns an error message instead of silence
5. if needed, switch to a cheaper or safer model rather than rewriting the stack

## For agents
Do not redesign the whole chatbot stack before confirming the current function path and env setup.
