# Project Handoff Recovery

## Recovered state from repo / deployment / chat

### What is already true
- `libbynatico/libby_live` is the working repo.
- Netlify production deploy has already succeeded.
- Repo root static deployment is the intended model.
- `index.html` is the main application surface.
- `netlify/functions/chat.js` is the serverless chat endpoint.
- Netlify environment variables are already configured.
- The earlier Netlify path errors were corrected.

### What was already attempted
- A Netlify/Codex run performed a release pass and produced a preview.
- The user did not observe enough visible change from that pass.
- Therefore, future rounds must optimize for obvious visible change, not internal-only refactors.

### What remains strategically unfinished
- Patient Zero is not yet canonicalized inside the repo.
- Chat context is not yet clearly tied to repo-resident case files.
- Interaction quality still needs strong visible improvement.
- The product surface still needs to communicate trust, status, and structure better.

## Product direction recovered from chat
Libby Live is intended to become:
- a public-facing guided intake and advocacy support portal
- a structured case-support workspace
- a practical live surface for demonstrations and stakeholder review
- a front-end that can eventually integrate with OpenClaw-driven automation

## Design requirements recovered from chat
The interface must feel:
- serious
- calm
- organized
- readable
- trustworthy
- like a real case portal

The interface must not feel:
- like startup SaaS
- like a toy admin panel
- like a speculative design mockup
- like a chatbot homepage

## Operational constraints
- Keep architecture static
- Keep secrets out of repo
- Keep deploy surface simple
- Favor visible releases with version bumps
- Prefer GitHub as source of truth and Netlify as deploy system
