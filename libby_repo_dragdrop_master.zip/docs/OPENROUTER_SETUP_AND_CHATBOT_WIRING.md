# OpenRouter Setup and Chatbot Wiring

## What OpenRouter is doing here
Libby Live should use OpenRouter only from the Netlify function, never directly from browser code.

## Current intended flow
1. Browser UI sends a request to:
   `/.netlify/functions/chat`
2. Netlify function reads:
   `OPENROUTER_API_KEY`
3. Netlify function POSTs to:
   `https://openrouter.ai/api/v1/chat/completions`
4. Netlify function returns a clean JSON response to the browser

## Required environment variable
- `OPENROUTER_API_KEY`

## Browser rule
Do not put the OpenRouter key into:
- `index.html`
- `.env.example`
- GitHub
- client-side storage

## Current API pattern
OpenRouter uses:
- `Authorization: Bearer <OPENROUTER_API_KEY>`
- endpoint: `https://openrouter.ai/api/v1/chat/completions`
- request body with a `messages` array
- optional `model`
- optional attribution headers:
  - `HTTP-Referer`
  - `X-OpenRouter-Title`

## Suggested function behavior
The Netlify function should:
- read `OPENROUTER_API_KEY` from server env
- accept `messages`
- optionally accept `model`
- send a chat completions request upstream
- return:
  - reply text
  - model used
  - clean error if upstream fails

## Minimum safe operator checklist
- key exists in Netlify environment variables
- browser only talks to `/.netlify/functions/chat`
- function returns visible error text instead of silent failure
- model choice is explicit or controlled
- the UI shows send / in-progress / error / success state

## Notes for future rounds
If model selection becomes expensive or confusing:
- keep a conservative default
- expose only a short allowed list in the UI
- let heavier model experimentation happen outside production

## Official implementation facts to remember
- OpenRouter exposes a single API endpoint for chat completions.
- The request shape is intentionally close to the OpenAI chat format.
- Messages are the core payload structure.
- Attribution headers are optional, not mandatory.
