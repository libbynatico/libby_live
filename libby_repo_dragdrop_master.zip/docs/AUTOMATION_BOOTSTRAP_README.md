# Automation Bootstrap Readme

## Goal
Reduce manual platform fiddling by making the repo itself the control surface.

## Immediate automation posture
Use GitHub and repo docs as the durable memory.
Use Netlify only for:
- deploys
- previews
- runtime environment variables

Use OpenClaw Lite later for:
- bounded task dispatch
- reminders
- stale-work detection
- controlled file prep

## Phase-1 automation rules
1. Human-approved releases only
2. No direct secret handling in repo
3. No uncontrolled outbound submissions
4. No destructive file actions without explicit approval
5. GitHub remains the canonical surface for instructions, prompts, structure, and release memory

## Required repo-side automation files
- `CLAUDE.md`
- `docs/NEXT_ACTIONS_FOR_CLAUDE.md`
- `docs/VERSIONING_RULES.md`
- `docs/APPROVAL_MATRIX.md`
- `docs/OPENCLAW_LITE_OPERATOR.md`
- `docs/OPENROUTER_SETUP_AND_CHATBOT_WIRING.md`
- `docs/patient_zero/*`
