# Agent Roles and Handshakes

## Core role split
- ChatGPT
  - architecture
  - governance logic
  - synthesis across materials
  - operating model design

- Claude
  - repo execution
  - UX improvement
  - file generation
  - final integration
  - visible release passes

- Gemini
  - Drive and Gmail retrieval
  - inventory and search
  - Google-native research
  - high-context cheap reading

- OpenClaw Lite
  - future dispatcher
  - bounded task runner
  - reminder / heartbeat / state-awareness layer

- low-cost utility models
  - transforms
  - boilerplate
  - CSV / JSON shaping
  - repetitive code generation
  - never the canonical doctrine setter

## Handshake discipline
Each significant transfer should state:
- source lane
- destination lane
- purpose
- artifact(s) transferred
- unresolved questions
- required next action
- approval requirement, if any

## Safe handoff examples
- Gemini -> Claude
  - evidence inventory
  - Drive/Gmail audit summaries
  - source lists
- ChatGPT -> Claude
  - operating prompt
  - release brief
  - repo structure decisions
- Claude -> OpenClaw Lite
  - bounded repeatable tasks only
  - never ambiguous external action
