# Drive and Gmail Audit Summary

## Summary
Drive contains the doctrine layer.
Gmail contains the active work layer.
The repo must become the canon layer.

## Highest-value doctrine findings
- Libby constitution and behavioral posture
- global personalization and account doctrine
- Heartbeat / Handshake / Initiative automation logic
- agent role split
- phase-1 platform scope
- launch gating

## Highest-value active work findings
- Patient Zero onboarding package
- patient reality / experience email
- prior Libby Live milestone report
- prior Claude code build brief

## Interpretation
The problem is not lack of ideas.
The problem is lack of canonical consolidation.
