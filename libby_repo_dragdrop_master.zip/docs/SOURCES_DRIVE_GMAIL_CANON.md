# Sources - Drive / Gmail Canon

This file records the highest-signal doctrine and operational materials already recovered from Google Drive and Gmail.

## Drive canon recovered
1. `LIBBY_CONSTITUTION_v1.md`
   - Libby identity
   - role boundaries
   - status language
   - escalation logic
   - interaction posture

2. `LIBBY - GLOBAL PERSONALIZATION SETTINGS`
   - reusable account instructions
   - project segmentation logic
   - personalization and continuity layer

3. `GPT_ENGINEER.docx`
   - Heartbeat / Handshake / Initiative architecture
   - middleware / automation framing
   - GitHub as durable operational memory

4. `GEMINI_TEAM_INTAKE.docx`
   - agent role directives
   - intake behavior
   - responsibility split

5. `NATICO Platform Architecture and Phase-1 Scope`
   - layered platform framing
   - NATICO / Libby / OpenClaw relationship
   - phase-oriented build logic

6. `NATICO Phase-1 Launch Gating Checklist`
   - readiness gates
   - pre-launch discipline
   - bounded rollout logic

## Gmail canon recovered
1. `Patient_zero_onboarding` - 2026-04-01
   - substantial Patient Zero handoff package
   - primary source for current Patient Zero onboarding layer

2. `Fwd: Urgent help plea - Matthew Herbert - "Patient_reality" & "Patient_experience"` - 2026-03-25
   - direct lived-experience and care continuity narrative
   - critical for Patient Reality framing

3. `LIBBY_LIVE Phase 2 — Milestones 1 & 2 Complete — Ready for Milestone 3`
   - prior governance/handshake/heartbeat build thinking
   - useful for recovering previously intended app capabilities

4. `claude code v1.02 progress`
   - prior larger multi-file portal brief
   - useful for understanding intended product shape

## Canon rule
Drive and Gmail are source material.
GitHub repo files become canon only after the material is deliberately ingested, cleaned, and assigned stable source references.
