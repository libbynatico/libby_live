# Patient Zero Build Brief

## Goal
Canonicalize Patient Zero into repo-resident files so Libby can work from durable context rather than scattered chat memory.

## Required distinctions
Patient Zero files must distinguish:
- confirmed facts
- patient realities
- reusable truths
- unresolved gaps
- source references

## Required core files
- `docs/patient_zero/patient_zero_onboarding_master.md`
- `docs/patient_zero/source_index.md`
- `docs/patient_zero/evidence_ledger.csv`
- `docs/patient_zero/patient_zero_context_summary.md`

## Provenance rule
Do not fabricate citations.
If provenance is incomplete:
- mark the item provisional
- preserve the source thread or doc name
- assign a stable source ID anyway

## Immediate use
The chatbot should eventually consume:
- context summary
- key truths
- recent high-value evidence entries
- unresolved gaps
