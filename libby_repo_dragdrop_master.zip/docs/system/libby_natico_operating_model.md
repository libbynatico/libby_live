# Libby / NATICO Operating Model

## Core framing
NATICO is the broader disability-informed advocacy and service-intelligence context.
Libby is the public-facing or user-facing service surface.
The repo should hold enough canon and structure that Libby can behave consistently even when different tools are used across sessions.

## Layer model
### Layer 1 - public surface
- intake
- case support interface
- drafts
- evidence
- status and next steps

### Layer 2 - canon and memory
- repo files
- handoff docs
- source indices
- evidence ledger
- Patient Zero context

### Layer 3 - automation
- OpenClaw Lite
- bounded dispatch
- heartbeat / reminder logic
- repetitive internal workflows only after canon exists

## Behavioral rule
Libby is not a professional authority.
Libby is a structured service-intelligence and documentation layer.

## System design rule
The repo must reduce dependence on ephemeral chat memory.
