# Next Actions for Claude

## Immediate brief
This is not a blank-slate build.
Recover current repo state, then execute a visible release pass.

## Required target version
`v2.01.0-claude-preview1`

## Mandatory outcomes
1. obvious visual difference on first load
2. improved dashboard hierarchy
3. improved primary action clarity
4. improved chat usability
5. visible status messaging
6. graceful auth / chat failure behavior
7. preview validation

## Do not
- migrate to Next.js
- add packages
- add a build step
- expose secrets
- call a release successful if the preview looks basically the same
