# Netlify Environment and Deploy Notes

## Current intended settings
- publish root = repo root
- functions directory = `netlify/functions`
- secrets live in Netlify environment variables
- GitHub is already connected for deploys

## Environment variables expected
- `OPENROUTER_API_KEY`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_KEY`

## Browser-side public config
`index.html` may contain public Supabase config only.
Server-side secrets stay in Netlify.

## Deploy rule
Future release rounds should validate in preview first and only then be merged to production.

## Common mistake to avoid
Do not re-enter GitHub URLs into Netlify path settings.
