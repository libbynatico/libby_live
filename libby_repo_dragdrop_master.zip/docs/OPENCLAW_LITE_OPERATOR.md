# OpenClaw Lite Operator Notes

## Immediate position
OpenClaw Lite should be treated as a future bounded orchestrator, not as the first place where canon lives.

## Preconditions before deeper tie-in
- repo canon files exist
- approval matrix exists
- stable prompts exist
- patient zero files exist
- safe repeatable tasks are enumerated

## Good first tasks
- scheduled stale-file reminders
- issue / backlog digestion
- evidence-index refresh prompts
- release checklist prep
- daily or weekly state summaries

## Bad first tasks
- autonomous external messaging
- autonomous filing / submission
- destructive file or record actions
- ambiguous credentialed operations
