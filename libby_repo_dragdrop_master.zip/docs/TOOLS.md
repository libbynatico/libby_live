# Tools

## Netlify
Use for:
- preview deploys
- production deploys
- runtime environment variables
- serverless function hosting

Do not use Netlify as the main system memory.

## GitHub
Use for:
- source of truth
- durable prompts
- docs
- change history
- release discipline

## Supabase
Use for:
- auth
- future persistence if needed

## OpenRouter
Use for:
- server-side chat completions only

## Google Drive / Gmail
Use for:
- source discovery
- prior doctrine recovery
- evidence and historical materials to be canonicalized into the repo

## OpenClaw Lite
Use later for:
- bounded automation
- scheduling
- reminders
- task dispatch
