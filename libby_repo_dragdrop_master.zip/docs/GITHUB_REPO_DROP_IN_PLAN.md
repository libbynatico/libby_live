# GitHub Repo Drop-In Plan

## Intent
This pack is designed to be uploaded directly into `libbynatico/libby_live` so the repo gains durable project memory and execution guidance.

## Practical upload path
1. Extract zip locally.
2. Open repo in GitHub.
3. Add files at repo root and under `docs/` and `.github/`.
4. Commit with message:
   `docs: add canonical handoff, automation, and patient zero pack`
5. Let Claude read `CLAUDE.md` before the next code round.

## After upload
- do not ask a fresh agent to rediscover architecture
- direct it to `CLAUDE.md`
- direct it to `docs/NEXT_ACTIONS_FOR_CLAUDE.md`
- require visible version bumps and preview validation
