# Patient Zero Context Summary

## One-paragraph summary
Matthew Herbert is the current Patient Zero case model for Libby / NATICO. The case combines severe chronic illness, repeated surgery, disability, traumatic brain injury-related executive burden, administrative fragmentation, housing instability, and active legal / advocacy escalation. The practical need is a system that can preserve continuity, structure evidence, generate drafts, and reduce the overhead of self-advocacy while multiple crises are active at once.

## Use this context for
- demo-safe case summary rendering
- chatbot grounding
- evidence linkage
- draft generation
- case portal hierarchy design
- proof that Libby is solving a real continuity problem rather than showing abstract features

## High-value stable truths
- continuity failure is a central problem
- documentation structure is part of care survival, not just bureaucracy
- the burden is simultaneous: medical, administrative, housing, disability, and legal
- AI tools are being used as coordination prosthetics, not as authority replacements
- the system should reduce founder overhead, not add more platform friction

## Near-term portal implications
The interface should make it easy to surface:
- current situation
- realities / truths
- evidence
- active matters
- unresolved gaps
- next best action
- clear status

## Current source base
- PZ-SRC-001 through PZ-SRC-010
- see `source_index.md`
- see `evidence_ledger.csv`
