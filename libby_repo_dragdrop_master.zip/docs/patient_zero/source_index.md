# Patient Zero Source Index

## PZ-SRC-001
- Type: Gmail thread
- Title: `Patient_zero_onboarding`
- Date: 2026-04-01
- Confidence: high for broad narrative and timeline anchors
- Use: primary onboarding source for current Patient Zero summary
- Notes: includes broad identity, timeline, active matters, family context, and priority path

## PZ-SRC-002
- Type: Gmail thread
- Title: `Fwd: Urgent help plea - Matthew Herbert - "Patient_reality" & "Patient_experience"`
- Date: 2026-03-25
- Confidence: high for lived experience and present functioning narrative
- Use: patient reality layer
- Notes: valuable for nutrition, mobility, deconditioning, support urgency, and continuity-of-care framing

## PZ-SRC-003
- Type: Gmail thread
- Title: `LIBBY_LIVE Phase 2 — Milestones 1 & 2 Complete — Ready for Milestone 3`
- Date: 2026-03-27
- Confidence: medium-high for prior intended application structure
- Use: governance / product structure recovery
- Notes: references handshakes, heartbeats, audience-aware outputs, and staged product milestones

## PZ-SRC-004
- Type: Gmail thread
- Title: `claude code v1.02 progress`
- Date: 2026-03-27
- Confidence: medium-high for intended portal scope and IA
- Use: portal build intent and design direction
- Notes: strong evidence of intended secure portal / intake / case / evidence / draft / chat product structure

## PZ-SRC-005
- Type: Google Drive doctrine
- Title: `LIBBY_CONSTITUTION_v1.md`
- Confidence: high for Libby role, posture, and status language
- Use: system behavior canon

## PZ-SRC-006
- Type: Google Drive doctrine
- Title: `LIBBY - GLOBAL PERSONALIZATION SETTINGS`
- Confidence: high for project segmentation, personalization, and continuity behavior
- Use: account/project operating doctrine

## PZ-SRC-007
- Type: Google Drive doctrine
- Title: `GPT_ENGINEER.docx`
- Confidence: high for Heartbeat / Handshake / Initiative architecture
- Use: automation / orchestration canon

## PZ-SRC-008
- Type: Google Drive doctrine
- Title: `GEMINI_TEAM_INTAKE.docx`
- Confidence: medium-high for role directives
- Use: agent split / workflow model

## PZ-SRC-009
- Type: Google Drive doctrine
- Title: `NATICO Platform Architecture and Phase-1 Scope`
- Confidence: high for layered platform framing
- Use: long-range system design

## PZ-SRC-010
- Type: Google Drive doctrine
- Title: `NATICO Phase-1 Launch Gating Checklist`
- Confidence: high for launch gating logic
- Use: release discipline and readiness logic
