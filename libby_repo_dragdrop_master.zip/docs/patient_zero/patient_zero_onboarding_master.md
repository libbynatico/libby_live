# Patient Zero Onboarding Master

## Identity
- Name: Matthew Gordon Herbert
- Date of birth: 1988-11-29
- Current broad context recovered from source material: recovering in Ontario while navigating overlapping medical, administrative, legal, disability, and housing matters

## Core summary
Matthew Herbert is navigating multiple simultaneous crises without meaningful representation. Recovered materials describe longstanding Crohn's disease, permanent ileostomy history, moderate traumatic brain injury with executive dysfunction, auditory processing difficulty, repeated surgeries, post-operative complications, disability support transitions, housing instability, administrative gatekeeping, and active attempts to convert chaotic evidence into a structured advocacy system.

## Primary diagnoses / conditions repeatedly referenced
- Crohn's disease
- permanent ileostomy / repeated ileostomy revision history
- moderate traumatic brain injury
- executive dysfunction
- auditory processing difficulty
- severe physical deconditioning following prolonged illness and hospitalization
- dental deterioration affecting intake and nutrition
- post-surgical recovery limitations

## High-confidence timeline recovered from source email
### Early history
- Oct 2001: rollerblading-related TBI with loss of consciousness and amnesia
- 2002: Crohn's diagnosis

### Surgical history highlights
- 2013: emergency ileostomy
- 2014: total proctocolectomy with end ileostomy by Dr. Shawn Forbes
- approximately 15 surgeries across Crohn's / hernia / prolapse / stricturing history

### 2025 acute sequence
- Jun 23, 2025: ileoscopy / no stoma output / vomiting
- Jun 26, 2025: Cambridge Memorial Hospital admission with high-grade SBO at ileostomy site
- Jun 28, 2025: Penner resection / ileostomy revision
- Jul 2025: recurrent obstruction and diagnostic instability
- Aug 8, 2025: discharge summary reportedly described van-living / precarious psychosocial situation
- Aug-Nov 2025: ongoing alleged unsafe discharge consequences, home-care denial, repeated emergency use
- Nov 10, 2025: CMH ER visit with alleged further care failures

### 2026 recovery sequence
- Jan 20, 2026: Juravinski laparotomy, small bowel resection, ileostomy resiting to RLQ by Dr. Forbes
- two Crohn's stricture segments resected
- parastomal hernia identified
- approximately 450 cm small bowel remaining
- Feb 5, 2026: follow-up reported improved output and skin dehiscence without infection
- Mar 9, 2026: ODSP approval reported with retroactive payment
- Mar 31, 2026: ODSP address / accommodation verification letter received
- Apr 1, 2026: Cambridge condo lease begins

## Current lived realities recovered from sources
- cannot support own body weight for more than about 60 seconds in public settings
- uses a walker in public
- feels far from being physically ready to be the partner / parent he wants to be
- has muscle deterioration following major weight loss and bedrest
- has extremely low intake and poor appetite influenced by severe dental decay
- is seeking meaningful nutrition and intestinal-failure support
- experiences major administrative burden and is trying to self-direct the entire case using AI tools and structured documentation

## Current active matters
### Medical / care continuity
- post-operative recovery
- GI continuity
- intestinal failure / nutrition support
- home-care continuity
- ostomy management and supply continuity

### Litigation / hospital accountability
- medical negligence / systemic-failure framing related to CMH and connected care failures
- need for discharge records, referral records, and denial / approval documents

### Disability income and benefits
- ODSP worker assignment and address update
- related equipment / special-needs funding activation
- Ontario Works history and caseworker-related administrative friction

### Transportation / licensing
- MTO / driver licence reinstatement dispute

### Tax / financial liability
- CRA director's liability assessment from failed business history

### Housing / stability
- Cambridge condo lease start
- transition out of prior instability
- support planning with growing family demands

## Family / support context
- Partner: Kellsie Hnatejko
- Expected twins referenced as due June 30, 2026 in source email
- strong concern about ability to physically and administratively support family while unresolved systems issues continue

## Patient realities / usable truths
- Matthew has been forced to become his own organizer, recorder, and advocate because systems repeatedly failed to hold continuity.
- He is carrying simultaneous medical, administrative, and legal burdens while recovering physically.
- The problem is not just illness; it is the interaction between illness, disability, and fragmented systems.
- Structured documentation is not optional for this case. It is part of survival and continuity.
- AI tools are being used as a prosthetic documentation and coordination layer, not as a replacement for licensed care or legal authority.

## Gaps that remain unresolved
- full discharge summary content
- complete Ontario Health atHome / home-care records
- full referral chain and denial / approval documentation
- verified chronology for every post-CMH event
- complete CRA / MTO source packages inside the repo
- canonical source capture for all screenshots, exports, and attachments

## Source references
- PZ-SRC-001 - Gmail thread `Patient_zero_onboarding` (2026-04-01)
- PZ-SRC-002 - Gmail thread `Fwd: Urgent help plea - Matthew Herbert - "Patient_reality" & "Patient_experience"` (2026-03-25)
- PZ-SRC-003 - Gmail thread `LIBBY_LIVE Phase 2 — Milestones 1 & 2 Complete — Ready for Milestone 3`
- PZ-SRC-004 - Gmail thread `claude code v1.02 progress`
