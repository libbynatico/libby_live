# Next 3 Runs

## Run 1 - Visible release pass
Target version: `v2.01.0-claude-preview1`
Goals:
- obvious visual difference
- stronger dashboard hierarchy
- clearer primary actions
- improved chat usability
- better auth / chat / save status messaging
- validated preview

## Run 2 - Patient Zero repo canon
Goals:
- build / verify patient_zero files
- assign stable source IDs
- connect source index and evidence ledger
- produce a clean context summary usable by chat

## Run 3 - Chat context integration
Goals:
- make chat consume patient_zero context summary
- surface source-linked context in responses where useful
- add controlled failure and status visibility
- prepare demo-safe interaction flow
