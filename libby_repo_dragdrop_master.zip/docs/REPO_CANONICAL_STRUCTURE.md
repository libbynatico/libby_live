# Repo Canonical Structure

## Root
- `index.html`
- `netlify/functions/chat.js`
- `CLAUDE.md`
- `CHANGELOG.md`
- `README.md`
- `.env.example`
- `netlify.toml`

## Docs
- `docs/PROJECT_HANDOFF_RECOVERY.md`
- `docs/SOURCES_DRIVE_GMAIL_CANON.md`
- `docs/AGENT_ROLES_AND_HANDSHAKES.md`
- `docs/AUTOMATION_BOOTSTRAP_README.md`
- `docs/VERSIONING_RULES.md`
- `docs/APPROVAL_MATRIX.md`
- `docs/OPENROUTER_SETUP_AND_CHATBOT_WIRING.md`
- `docs/NETLIFY_ENV_AND_DEPLOY.md`
- `docs/OPENCLAW_LITE_OPERATOR.md`
- `docs/NEXT_ACTIONS_FOR_CLAUDE.md`
- `docs/NEXT_3_RUNS.md`
- `docs/system/libby_natico_operating_model.md`
- `docs/patient_zero/*`

## Github support
- `.github/pull_request_template.md`
- `.github/ISSUE_TEMPLATE/release-round.md`
- `.github/ISSUE_TEMPLATE/patient-zero-ingest.md`
