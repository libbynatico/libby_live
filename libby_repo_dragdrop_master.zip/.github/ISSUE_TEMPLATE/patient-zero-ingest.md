---
name: Patient Zero ingest
about: Canonicalize a Patient Zero source into repo files
title: "patient-zero: "
labels: ["patient-zero"]
assignees: []
---

## Source
State source ID and source name.

## Ingest target
- [ ] onboarding master
- [ ] source index
- [ ] evidence ledger
- [ ] context summary

## Rules
- do not fabricate citations
- preserve confirmed vs provisional distinctions
- add stable source ID
