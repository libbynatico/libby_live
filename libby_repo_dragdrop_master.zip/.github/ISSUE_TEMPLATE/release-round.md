---
name: Release round
about: Visible release pass for Libby Live
title: "release: "
labels: ["release-round"]
assignees: []
---

## Objective
State the release objective.

## Required visible outcomes
- [ ] version bump visible in UI
- [ ] preview visibly different from production
- [ ] primary actions clearer
- [ ] chat usability improved or preserved
- [ ] validation completed

## Constraints
- no framework migration
- no secret exposure
- preview-first
