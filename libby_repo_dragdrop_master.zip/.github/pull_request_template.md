## Summary
Explain what changed in plain language.

## Root cause
If fixing a bug, state the real root cause.

## Visible changes
List the changes a user can actually see.

## Interaction changes
List changes that affect usability or workflow.

## Validation
State what was checked in preview.

## Versioning
Confirm visible version bump if this was a meaningful release round.
